/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author khani
 */
public class User { // uesr class
    // instance variables
    String name;
    int gamesPlayed;

    // constructor to initialize new objects of the class
    public User(String name, int gamesPlayed) {
        this.name = name; 
        this.gamesPlayed = gamesPlayed;
    }
    // setter and getter methods for each of the instance variables
    public void setGamesPlayed(int gamesPlayed) {
        this.gamesPlayed = gamesPlayed;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public int getGamesPlayed() {
        return gamesPlayed;
    }

    public String getName() {
        return name;
    }
    // override and to string method to ouput detials of the objects
    @Override
    public String toString() {
        return name+"\n"+gamesPlayed+"\n";
    }
    
    
}
