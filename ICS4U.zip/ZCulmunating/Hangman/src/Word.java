/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author khani
 */
public abstract class Word { // abstract class; parent class to easyword, mediumword, and hardword
    // each child class will need to have the following instance variables
    protected String word;
    protected int numOfLetters;
    // each child class winn need to have the following getter methods
    public abstract int getLetters();
    public abstract String getWord();
}
