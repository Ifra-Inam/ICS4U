/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author khani
 */
public class EasyWord extends Word{ // easy word class is a child class of Word
    
    // instance variables
    private int numOfLetters;
    private String Word;
    
    // constructor to initialize new objects of the class
    public EasyWord(int numOfLetters, String Word) {
        this.numOfLetters = numOfLetters;
        this.Word = Word;
    }
    
    // getter methods
    @Override
    public String getWord() {
        return Word;
    }

    @Override
    public int getLetters() {
       return numOfLetters;
    }
    
    
    
    
    
}
